function Person(name, surname) {
    "use strict";
    this.name = name;
    this.surname = surname;
}
console.log(typeof Person);   //function