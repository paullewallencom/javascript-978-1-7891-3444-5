class myClass {
  constructor(value) {
    return { property1: value, property2: "" };
  }
}

var x = new myClass("foo");
