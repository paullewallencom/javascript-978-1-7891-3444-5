//C#

public int Sum(int x, int y) {
	return Sum(x, y, 0);
}

public int Sum(int x, int y, int z) {
	return x + y + z;
}
