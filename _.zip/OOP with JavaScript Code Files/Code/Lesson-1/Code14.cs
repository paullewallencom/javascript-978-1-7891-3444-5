function Sum(x, y, z) {
	x = x?x:0;
	y = y?y:0;
	z = z?z:0;
	return x + y + z;
}
