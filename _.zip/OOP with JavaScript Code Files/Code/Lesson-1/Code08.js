var Person = class {
  constructor(name, surname) {
    this.name = name;
    this.surname = surname;
  }
};
var person = new Person("John", "Smith");
