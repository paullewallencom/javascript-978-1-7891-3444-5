var person = {};
person.name = "John";
person.surname = "Smith";
person.address = {
                   street: "123 Duncannon Street",
                   city: "London",
                   country: "United Kingdom"
                 };
person.age = 28;
