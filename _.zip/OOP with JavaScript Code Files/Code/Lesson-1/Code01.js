var person = {name: "John",
               surname: "Smith",
               address: {
                 street: "13 Duncannon Street",
                 city: "London",
                 country: "United Kingdom"
               }};
