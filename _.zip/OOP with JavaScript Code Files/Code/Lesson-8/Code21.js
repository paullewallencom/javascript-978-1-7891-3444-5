require(["geoModule"], function(geoModule) {
	console.log(geoModule.calculateCircumference(5));
});
