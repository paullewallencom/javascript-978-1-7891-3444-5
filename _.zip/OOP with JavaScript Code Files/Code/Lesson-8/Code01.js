var myApplication = {
	version: "1.0",
	name: "My Application",
	config: {/*...*/},
	init: function() {/*...*/}
};

console.log(myApplication.name);		//My Application
myApplication.init();
