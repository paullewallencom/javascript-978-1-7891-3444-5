var myApplication = {};

(function() {
	this.version = "1.0";
	this.name = "My Application";
	this.config = {/*...*/};
	this.init = function() {/*...*/};
}).apply(myApplication);