var myApplication = {};

(function(nameSpace) {
	nameSpace.version = "1.0";
	nameSpace.name = "My Application";
	nameSpace.config = {/*...*/};
	nameSpace.init = function() {/*...*/};
})(myApplication);

