function Person(name, surname) {
  this.name = name;
  this.surname = surname;
}

function Hotel(name, address) {
  this.name = name;
  this.address = address;
}


