var myApplication = {
	version: "1.0",
	name: "My Application",
	config: {
		ui: {
		  backgroundColor: "green",
		  fontSize: 12
		},
		localization: {
		  language: "English",
		  dateFormat: "MM-dd-yyyy"
		}
	},
	init: function() {/*...*/}
};