import {circumference} from "geoModule";

console.log(circumference(5));
