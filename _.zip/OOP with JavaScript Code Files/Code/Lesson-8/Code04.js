var myApplication = {
	version: "1.0",
	name: "My Application",
	init: function() {/*...*/}
};

myApplication.config = {};
myApplication.config.ui = {
	backgroundColor: "green",
	fontSize: 12
};
myApplication.config.localization = {
	language: "English",
	dateFormat: "MM-dd-yyyy"
};
									
myApplication.config.localization.language = "Italian",
myApplication.config.localization.dateFormat = "dd-MM-yyyy";