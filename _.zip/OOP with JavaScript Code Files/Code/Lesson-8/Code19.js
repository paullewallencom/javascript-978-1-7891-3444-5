var geoModule = require("./geoModule");

console.log(geoModule.calculateCircumference(5));
