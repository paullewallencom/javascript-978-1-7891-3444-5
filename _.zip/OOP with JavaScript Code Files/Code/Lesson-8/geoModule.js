var pi = 3.14;

export function circumference(radius) {
	return 2*pi*radius;
}

export function circleArea(radius) {
	return pi*radius*radius;
}