var myApplication = myApplication || {};
myApplication = {
	version: "1.0",
	name: "My Application",
	config: {/*...*/},
	init: function() {/*...*/}
};
